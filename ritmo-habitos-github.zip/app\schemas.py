from datetime import date
from pydantic import BaseModel, ConfigDict, Field


class HabitOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: int
    name: str
    category: str
    description: str
    target: str
    active: bool


class CheckInCreate(BaseModel):
    habit_id: int
    checkin_date: date | None = None
    completed: bool = True
    note: str | None = Field(default=None, max_length=500)


class CheckInOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: int
    habit_id: int
    checkin_date: date
    completed: bool
    note: str | None
    created_at: str


class TodayHabit(BaseModel):
    habit: HabitOut
    completed: bool
    note: str | None = None


class TodayOut(BaseModel):
    date: date
    completed: int
    total: int
    percentage: float
    habits: list[TodayHabit]


class StatsOut(BaseModel):
    days_tracked: int
    total_completed: int
    possible_checkins: int
    completion_rate: float
    current_streak: int
    best_streak: int


class MonthlyDay(BaseModel):
    date: date
    completed: int


class MonthlyHabit(BaseModel):
    habit_id: int
    name: str
    completed: int


class MonthlyStatsOut(BaseModel):
    month: str
    days_in_period: int
    days_with_data: int
    total_completed: int
    possible_checkins: int
    completion_rate: float
    best_day: str | None
    by_day: list[MonthlyDay]
    by_habit: list[MonthlyHabit]
