const state = { token: localStorage.getItem('habits-api-token') || '', today: null };
const $ = (selector) => document.querySelector(selector);
let isLoading = false;
let refreshQueued = false;

function apiHeaders() {
  return state.token ? { 'X-API-Token': state.token } : {};
}

async function api(path, options = {}) {
  const response = await fetch(path, { ...options, headers: { ...apiHeaders(), ...(options.headers || {}) } });
  if (!response.ok) {
    const message = response.status === 401 ? 'Token inválido. Revísalo en configuración.' : `No se pudo completar la solicitud (${response.status}).`;
    throw new Error(message);
  }
  return response.json();
}

function showToast(message) {
  const toast = $('#toast');
  toast.textContent = message;
  toast.classList.add('show');
  window.setTimeout(() => toast.classList.remove('show'), 2800);
}

function renderToday(data) {
  state.today = data;
  $('#progress-value').textContent = `${data.percentage}%`;
  $('#progress-count').textContent = `${data.completed} de ${data.total} completados`;
  $('#progress-bar').style.width = `${data.percentage}%`;
  $('#progress-message').textContent = data.completed === data.total ? 'Día completo' : data.completed ? 'Buen ritmo' : 'Empieza con uno';
  const displayDate = new Date(`${data.date}T12:00:00`);
  $('#date-label').textContent = new Intl.DateTimeFormat('es', { weekday: 'long', day: 'numeric', month: 'long' }).format(displayDate);
  $('#day-kicker').textContent = new Intl.DateTimeFormat('es', { weekday: 'long', day: '2-digit', month: 'short' }).format(displayDate).toUpperCase();
  $('#habit-list').innerHTML = data.habits.map(({ habit, completed }, index) => `
    <button class="habit ${completed ? 'done' : ''}" data-habit-id="${habit.id}" type="button" aria-pressed="${completed}">
      <span class="habit-number">${String(index + 1).padStart(2, '0')}</span>
      <span class="habit-content"><span class="habit-topline"><span class="habit-category">${habit.category}</span><span class="habit-priority">Prioridad ${index + 1}</span></span><span class="habit-name">${habit.name}</span><span class="habit-description">${habit.description}</span><span class="habit-target">Objetivo · ${habit.target}</span></span>
      <span class="habit-check" aria-hidden="true"></span>
    </button>`).join('');
  document.querySelectorAll('.habit').forEach((item) => item.addEventListener('click', () => toggleHabit(item)));
}

async function toggleHabit(item) {
  const habitId = Number(item.dataset.habitId);
  const currentlyDone = item.classList.contains('done');
  item.disabled = true;
  item.classList.toggle('done', !currentlyDone);
  item.setAttribute('aria-pressed', String(!currentlyDone));
  try {
    await api('/checkins', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ habit_id: habitId, completed: !currentlyDone }) });
    await loadData();
  } catch (error) {
    item.classList.toggle('done', currentlyDone);
    item.setAttribute('aria-pressed', String(currentlyDone));
    showToast(error.message);
    item.disabled = false;
  }
}

async function loadData() {
  if (isLoading) {
    refreshQueued = true;
    return;
  }
  isLoading = true;
  $('#sync-status').textContent = 'Sincronizando...';
  try {
    const selectedMonth = $('#month-picker').value;
    const [today, stats, monthly] = await Promise.all([
      api('/checkins/today'),
      api('/stats'),
      api(`/stats/monthly?month=${selectedMonth}`)
    ]);
    renderToday(today);
    $('#current-streak').textContent = stats.current_streak;
    $('#best-streak').textContent = stats.best_streak;
    $('#completion-rate').textContent = `${stats.completion_rate}%`;
    $('#sync-status').textContent = `Actualizado ${new Intl.DateTimeFormat('es', { hour: '2-digit', minute: '2-digit' }).format(new Date())}`;
    $('#connection-dot').className = 'connected';
    renderMonthly(monthly);
  } catch (error) {
    $('#habit-list').innerHTML = `<div class="error">${error.message}<br><button class="text-button" id="open-settings">Abrir configuración</button></div>`;
    $('#sync-status').textContent = 'Requiere conexión';
    $('#connection-dot').className = 'offline';
    $('#open-settings')?.addEventListener('click', openSettings);
  } finally {
    isLoading = false;
    if (refreshQueued) {
      refreshQueued = false;
      void loadData();
    }
  }
}

function renderMonthly(data) {
  $('#monthly-rate').textContent = `${data.completion_rate}%`;
  $('#monthly-completed').textContent = data.total_completed;
  $('#monthly-best-day').textContent = data.best_day
    ? new Intl.DateTimeFormat('es', { day: 'numeric', month: 'short' }).format(new Date(`${data.best_day}T12:00:00`))
    : '—';

  const maxDaily = Math.max(...data.by_day.map((item) => item.completed), 1);
  $('#daily-chart').innerHTML = data.by_day.map((item) => {
    const height = Math.max((item.completed / maxDaily) * 100, item.completed ? 12 : 3);
    const day = new Date(`${item.date}T12:00:00`).getDate();
    return `<span class="day-bar" style="height:${height}%" title="${item.date}: ${item.completed} hábitos"><i>${day}</i></span>`;
  }).join('');

  const maxHabit = Math.max(...data.by_habit.map((item) => item.completed), 1);
  $('#habit-chart').innerHTML = data.by_habit.map((item) => {
    const width = (item.completed / maxHabit) * 100;
    return `<div class="habit-bar-row"><span title="${item.name}">${item.name}</span><div><i style="width:${width}%"></i></div><strong>${item.completed}</strong></div>`;
  }).join('');
}

function openSettings() {
  $('#token-input').value = state.token;
  $('#settings-dialog').showModal();
  $('#token-input').focus();
}

$('#settings-button').addEventListener('click', openSettings);
$('#refresh-button').addEventListener('click', loadData);
$('#month-picker').value = new Date().toISOString().slice(0, 7);
$('#month-picker').addEventListener('change', loadData);
$('#settings-form').addEventListener('submit', (event) => {
  event.preventDefault();
  state.token = $('#token-input').value.trim();
  localStorage.setItem('habits-api-token', state.token);
  $('#settings-dialog').close();
  loadData();
});

loadData();
