# Atajo de iPhone — registro diario

El Atajo usa la acción **Obtener contenido de URL** para enviar un POST al backend.

## Instalar Ritmo como app en iPhone

1. Conecta el iPhone y el PC a la misma red Wi-Fi.
2. Inicia la API en el PC.
3. En Safari del iPhone abre `http://IP_DE_TU_PC:8000`.
4. Pulsa **Compartir** → **Añadir a pantalla de inicio** → **Añadir**.
5. Abre **Ritmo** desde el nuevo icono y pulsa el engranaje para guardar el token `HABITS_API_TOKEN`.

La app se actualiza automáticamente cada 30 segundos cuando está abierta. Para registrar desde Atajos, el PC debe seguir encendido y la API debe estar ejecutándose. Si el iPhone pierde la Wi-Fi, la interfaz puede abrirse, pero no podrá sincronizar ni guardar registros.

## Usarla desde otra red

La dirección `192.168.0.104` solo funciona dentro de la red de casa. Para usar Ritmo desde datos móviles u otra Wi-Fi, la opción recomendada es **Tailscale**:

1. Instala Tailscale en el PC y en el iPhone.
2. Inicia sesión con la misma cuenta en ambos dispositivos.
3. En el PC ejecuta la API escuchando en todas las interfaces:

```powershell
$env:HABITS_API_TOKEN="habitos-2026"
& ".\.venv-1\Scripts\python.exe" -m uvicorn app.main:app --host 0.0.0.0 --port 8000
```

4. En la app Tailscale del PC busca su dirección `100.x.x.x`.
5. En el iPhone abre `http://100.x.x.x:8000` y usa esa misma dirección en el Atajo.

El PC debe permanecer encendido y la API ejecutándose. Tailscale crea una red privada entre tus dispositivos, por lo que no necesitas abrir puertos del router. Para una publicación permanente en Internet se recomienda usar un túnel HTTPS, como Cloudflare Tunnel, y no exponer directamente el puerto 8000.

## Opción recomendada

Primero prueba la API desde Safari:

`http://IP_DE_TU_PC:8000/health`

Si devuelve:

```json
{"status":"ok"}
```

el iPhone puede alcanzar el servidor.

## Crear el Atajo

1. Abre **Atajos**.
2. Pulsa `+`.
3. Nombre: `Registrar hábito`.
4. Añade **Elegir de menú**.
5. Crea 10 opciones:
   - Dormir 7–9 horas → ID 1
  - Ejercicio → ID 2
  - Alimentación saludable → ID 3
  - Relaciones de calidad → ID 4
  - Propósito → ID 5
  - Aprendizaje deliberado → ID 6
  - Reducir sedentarismo → ID 7
  - Gestión del estrés → ID 8
  - Reflexión y gratitud → ID 9
  - Limitar estímulos digitales → ID 10

6. Dentro de cada opción, añade **Obtener contenido de URL**.

Configura:

- Método: `POST`
- URL: `http://IP_DE_TU_PC:8000/checkins`
- Tipo de solicitud: `JSON`
- Header:
  - Nombre: `X-API-Token`
  - Valor: el mismo valor que pusiste en `HABITS_API_TOKEN`

Cuerpo JSON:

```json
{
  "habit_id": 1,
  "completed": true
}
```

Cambia `habit_id` en cada opción.

## Hacerlo más cómodo

En vez de 10 Atajos diferentes, puedes usar un solo Atajo con **Elegir de menú**.

También puedes crear automatizaciones en Atajos para determinados momentos del día. Apple permite activar automatizaciones personales por eventos como una hora concreta y, según el caso, configurar si se ejecutan automáticamente. Consulta la guía oficial de Apple si alguna opción de tu versión de iOS aparece con un nombre diferente.

## Recomendación de uso

No intentes registrar todo manualmente durante el día.

Una rutina práctica sería:

### Durante el día
Registrar:
- sueño
- ejercicio
- alimentación
- relaciones
- propósito
- aprendizaje
- reducción del sedentarismo
- gestión del estrés
- reflexión y gratitud
- límite de estímulos digitales

## Automatizaciones

Puedes crear una automatización de hora para abrir o ejecutar tu Atajo de revisión diaria.

En iOS actual:
Atajos → Automatización → `+` → Crear automatización personal → `Hora del día`.

Apple documenta este flujo en su guía de Atajos.
