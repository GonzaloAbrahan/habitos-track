$ErrorActionPreference = "Stop"

Write-Host "Comprobando API..."
Invoke-RestMethod http://127.0.0.1:8000/health

Write-Host "`nHábitos:"
Invoke-RestMethod `
  -Uri http://127.0.0.1:8000/habits `
  -Headers @{"X-API-Token"=$env:HABITS_API_TOKEN}
