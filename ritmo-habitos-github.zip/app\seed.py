from sqlalchemy import select
from sqlalchemy.orm import Session
from .models import Habit

DEFAULT_HABITS = [
    {
        "name": "Dormir 7–9 horas",
        "category": "Sueño",
        "description": "Dormir suficiente y mantener horarios relativamente estables.",
        "target": "7–9 h",
    },
    {
        "name": "Ejercicio",
        "category": "Salud física",
        "description": "Combinar fuerza, actividad cardiovascular y movimiento que puedas sostener.",
        "target": "Sesión de ejercicio planificada",
    },
    {
        "name": "Alimentación saludable",
        "category": "Nutrición",
        "description": "Priorizar alimentos poco procesados, proteínas, frutas y verduras.",
        "target": "Mayoría de alimentos integrales",
    },
    {
        "name": "Relaciones de calidad",
        "category": "Social",
        "description": "Dedicar tiempo real a familia, amigos o personas importantes.",
        "target": "Contacto significativo",
    },
    {
        "name": "Propósito",
        "category": "Dirección vital",
        "description": "Trabajar en algo conectado con tus objetivos y valores.",
        "target": "1 acción alineada al objetivo",
    },
    {
        "name": "Aprendizaje deliberado",
        "category": "Desarrollo",
        "description": "Practicar una habilidad importante con concentración y feedback.",
        "target": "Bloque de estudio/práctica",
    },
    {
        "name": "Reducir sedentarismo",
        "category": "Movimiento",
        "description": "Caminar y cortar períodos largos de sedentarismo.",
        "target": "Moverte durante el día",
    },
    {
        "name": "Gestión del estrés",
        "category": "Bienestar",
        "description": "Practicar una estrategia concreta para regular el estrés y recuperarte.",
        "target": "Pausa, respiración o descarga consciente",
    },
    {
        "name": "Reflexión y gratitud",
        "category": "Mental",
        "description": "Revisar qué salió bien, qué aprendiste y qué agradecer del día.",
        "target": "5 min de reflexión",
    },
    {
        "name": "Limitar estímulos digitales",
        "category": "Atención",
        "description": "Reducir scrolling y consumo pasivo para proteger la atención.",
        "target": "Uso intencional del celular",
    },
]


def seed_habits(db: Session) -> None:
    habits = db.scalars(select(Habit).order_by(Habit.id)).all()

    for index, values in enumerate(DEFAULT_HABITS):
        if index < len(habits):
            habit = habits[index]
            for field, value in values.items():
                setattr(habit, field, value)
            habit.active = True
        else:
            db.add(Habit(**values))

    for habit in habits[len(DEFAULT_HABITS):]:
        habit.active = False

    db.commit()
