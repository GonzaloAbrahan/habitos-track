import os
from calendar import monthrange
from datetime import date, datetime, timedelta
from pathlib import Path
from typing import Annotated

from fastapi import Depends, FastAPI, Header, HTTPException, Query
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles
from sqlalchemy import func, select
from sqlalchemy.orm import Session

from .database import Base, engine, get_db
from .models import CheckIn, Habit
from .schemas import CheckInCreate, CheckInOut, HabitOut, MonthlyStatsOut, StatsOut, TodayOut
from .seed import seed_habits

Base.metadata.create_all(bind=engine)

app = FastAPI(
    title="Hábitos Saludables API",
    description="Registro de hábitos saludables y desarrollo personal.",
    version="1.0.0",
)

STATIC_DIR = Path(__file__).parent / "static"
app.mount("/static", StaticFiles(directory=STATIC_DIR), name="static")


@app.on_event("startup")
def startup():
    with next(get_db()) as db:
        seed_habits(db)


def require_token(x_api_token: Annotated[str | None, Header()] = None):
    expected = os.getenv("HABITS_API_TOKEN")
    if expected and x_api_token != expected:
        raise HTTPException(status_code=401, detail="Token inválido")


TokenDep = Annotated[None, Depends(require_token)]


@app.get("/health")
def health():
    return {"status": "ok"}


@app.get("/habits", response_model=list[HabitOut], dependencies=[Depends(require_token)])
def list_habits(db: Session = Depends(get_db)):
    return db.scalars(
        select(Habit).where(Habit.active.is_(True)).order_by(Habit.id)
    ).all()


@app.get("/habits/{habit_id}", response_model=HabitOut, dependencies=[Depends(require_token)])
def get_habit(habit_id: int, db: Session = Depends(get_db)):
    habit = db.get(Habit, habit_id)
    if not habit:
        raise HTTPException(status_code=404, detail="Hábito no encontrado")
    return habit


@app.post(
    "/checkins",
    response_model=CheckInOut,
    dependencies=[Depends(require_token)],
)
def create_or_update_checkin(payload: CheckInCreate, db: Session = Depends(get_db)):
    checkin_date = payload.checkin_date or date.today()

    habit = db.get(Habit, payload.habit_id)
    if not habit or not habit.active:
        raise HTTPException(status_code=404, detail="Hábito no encontrado")

    checkin = db.scalar(
        select(CheckIn).where(
            CheckIn.habit_id == payload.habit_id,
            CheckIn.checkin_date == checkin_date,
        )
    )

    if checkin:
        checkin.completed = payload.completed
        checkin.note = payload.note
    else:
        checkin = CheckIn(
            habit_id=payload.habit_id,
            checkin_date=checkin_date,
            completed=payload.completed,
            note=payload.note,
        )
        db.add(checkin)

    db.commit()
    db.refresh(checkin)

    return CheckInOut(
        id=checkin.id,
        habit_id=checkin.habit_id,
        checkin_date=checkin.checkin_date,
        completed=checkin.completed,
        note=checkin.note,
        created_at=checkin.created_at.isoformat(),
    )


@app.get(
    "/checkins/today",
    response_model=TodayOut,
    dependencies=[Depends(require_token)],
)
def today(db: Session = Depends(get_db)):
    today_date = date.today()

    habits = db.scalars(
        select(Habit).where(Habit.active.is_(True)).order_by(Habit.id)
    ).all()

    checkins = db.scalars(
        select(CheckIn).where(CheckIn.checkin_date == today_date)
    ).all()

    by_habit = {item.habit_id: item for item in checkins}

    items = []
    for habit in habits:
        checkin = by_habit.get(habit.id)
        items.append(
            {
                "habit": habit,
                "completed": bool(checkin and checkin.completed),
                "note": checkin.note if checkin else None,
            }
        )

    completed = sum(1 for item in items if item["completed"])
    total = len(items)
    percentage = round((completed / total) * 100, 1) if total else 0

    return {
        "date": today_date,
        "completed": completed,
        "total": total,
        "percentage": percentage,
        "habits": items,
    }


@app.get(
    "/checkins",
    response_model=list[CheckInOut],
    dependencies=[Depends(require_token)],
)
def list_checkins(
    db: Session = Depends(get_db),
    checkin_date: date | None = Query(default=None, alias="date"),
):
    stmt = select(CheckIn).order_by(CheckIn.checkin_date.desc(), CheckIn.habit_id)
    if checkin_date:
        stmt = stmt.where(CheckIn.checkin_date == checkin_date)

    rows = db.scalars(stmt).all()

    return [
        CheckInOut(
            id=row.id,
            habit_id=row.habit_id,
            checkin_date=row.checkin_date,
            completed=row.completed,
            note=row.note,
            created_at=row.created_at.isoformat(),
        )
        for row in rows
    ]


def calculate_streaks(db: Session) -> tuple[int, int]:
    total_habits = db.scalar(
        select(func.count(Habit.id)).where(Habit.active.is_(True))
    ) or 0

    if total_habits == 0:
        return 0, 0

    rows = db.scalars(
        select(CheckIn).where(CheckIn.completed.is_(True))
    ).all()

    completed_by_day: dict[date, set[int]] = {}
    for row in rows:
        completed_by_day.setdefault(row.checkin_date, set()).add(row.habit_id)

    perfect_days = {
        day for day, habit_ids in completed_by_day.items()
        if len(habit_ids) == total_habits
    }

    current = 0
    cursor = date.today()
    while cursor in perfect_days:
        current += 1
        cursor -= timedelta(days=1)

    best = 0
    for day in sorted(perfect_days):
        streak = 1
        next_day = day + timedelta(days=1)
        while next_day in perfect_days:
            streak += 1
            next_day += timedelta(days=1)
        best = max(best, streak)

    return current, best


@app.get(
    "/stats",
    response_model=StatsOut,
    dependencies=[Depends(require_token)],
)
def stats(db: Session = Depends(get_db)):
    total_habits = db.scalar(
        select(func.count(Habit.id)).where(Habit.active.is_(True))
    ) or 0

    completed = db.scalar(
        select(func.count(CheckIn.id)).where(CheckIn.completed.is_(True))
    ) or 0

    tracked_days = db.scalar(
        select(func.count(func.distinct(CheckIn.checkin_date)))
    ) or 0

    possible = tracked_days * total_habits
    rate = round((completed / possible) * 100, 1) if possible else 0
    current, best = calculate_streaks(db)

    return {
        "days_tracked": tracked_days,
        "total_completed": completed,
        "possible_checkins": possible,
        "completion_rate": rate,
        "current_streak": current,
        "best_streak": best,
    }


@app.get(
    "/stats/monthly",
    response_model=MonthlyStatsOut,
    dependencies=[Depends(require_token)],
)
def monthly_stats(
    month: str | None = Query(default=None, pattern=r"^\d{4}-\d{2}$"),
    db: Session = Depends(get_db),
):
    selected_month = month or date.today().strftime("%Y-%m")
    first_day = datetime.strptime(selected_month, "%Y-%m").date().replace(day=1)
    last_day = first_day.replace(day=monthrange(first_day.year, first_day.month)[1])
    today = date.today()
    period_end = min(last_day, today) if first_day.year == today.year and first_day.month == today.month else last_day
    days_in_period = (period_end - first_day).days + 1 if period_end >= first_day else 0

    active_habits = db.scalars(
        select(Habit).where(Habit.active.is_(True)).order_by(Habit.id)
    ).all()
    rows = db.scalars(
        select(CheckIn).where(
            CheckIn.checkin_date >= first_day,
            CheckIn.checkin_date <= period_end,
            CheckIn.completed.is_(True),
        )
    ).all()

    by_day = {day: 0 for day in (first_day + timedelta(days=index) for index in range(days_in_period))}
    by_habit = {habit.id: 0 for habit in active_habits}
    for row in rows:
        by_day[row.checkin_date] = by_day.get(row.checkin_date, 0) + 1
        if row.habit_id in by_habit:
            by_habit[row.habit_id] += 1

    total_completed = len(rows)
    possible_checkins = days_in_period * len(active_habits)
    completion_rate = round((total_completed / possible_checkins) * 100, 1) if possible_checkins else 0
    best_day = max(by_day, key=by_day.get).isoformat() if by_day and max(by_day.values()) else None

    return {
        "month": selected_month,
        "days_in_period": days_in_period,
        "days_with_data": sum(1 for completed in by_day.values() if completed),
        "total_completed": total_completed,
        "possible_checkins": possible_checkins,
        "completion_rate": completion_rate,
        "best_day": best_day,
        "by_day": [{"date": day, "completed": completed} for day, completed in by_day.items()],
        "by_habit": [
            {"habit_id": habit.id, "name": habit.name, "completed": by_habit[habit.id]}
            for habit in active_habits
        ],
    }


@app.get("/")
def root():
    return FileResponse(STATIC_DIR / "index.html")
